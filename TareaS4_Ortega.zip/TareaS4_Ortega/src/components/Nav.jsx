import React from 'react';

export default function Nav({ vistaActual, setVistaActual }) {
  return (
    <nav className="navbar navbar-expand-lg navbar-dark bg-dark mb-4 shadow-sm">
      <div className="container">
        <span className="navbar-brand">Menú Principal</span>
        <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
          <span className="navbar-toggler-icon"></span>
        </button>
        <div className="collapse navbar-collapse" id="navbarNav">
          <ul className="navbar-nav ms-auto">
            <li className="nav-item">
              <button 
                className={`nav-link btn btn-link ${vistaActual === 'estudiantes' ? 'active fw-bold text-warning' : 'text-white'}`}
                onClick={() => setVistaActual('estudiantes')}
              >
                👥 Gestión de Estudiantes
              </button>
            </li>
            <li className="nav-item">
              <button 
                className={`nav-link btn btn-link ${vistaActual === 'materias' ? 'active fw-bold text-warning' : 'text-white'}`}
                onClick={() => setVistaActual('materias')}
              >
                📚 Módulo de Materias
              </button>
            </li>
          </ul>
        </div>
      </div>
    </nav>
  );
}