import React, { useState } from 'react';
import MateriaModal from './MateriaModal';

export default function Materias() {
  const [materias, setMaterias] = useState([
    { codigo: 'MAT-101', nombre: 'Programación Web I', descripcion: 'Fundamentos de HTML, CSS y JavaScript moderno.', creditos: 4, estado: 'Activo' },
    { codigo: 'MAT-102', nombre: 'Bases de Datos', descripcion: 'Diseño y modelado de bases de datos relacionales.', creditos: 3, estado: 'Activo' }
  ]);

  const [showModal, setShowModal] = useState(false);
  const [materiaActual, setMateriaActual] = useState(null);

  const handleAgregar = () => {
    setMateriaActual(null);
    setShowModal(true);
  };

  const handleActualizar = (materia) => {
    setMateriaActual(materia);
    setShowModal(true);
  };

  const handleSaveMateria = (materiaData) => {
    if (materiaActual) {
      setMaterias(materias.map(m => m.codigo === materiaData.codigo ? materiaData : m));
    } else {
      const existe = materias.some(m => m.codigo === materiaData.codigo);
      if (existe) {
        alert('Ya existe una materia registrada con este código.');
        return;
      }
      setMaterias([...materias, materiaData]);
    }
  };

  return (
    <div className="container my-4">
      <div className="d-flex justify-content-between align-items-center mb-4">
        <h2>📚 Módulo de Materias</h2>
        <button className="btn btn-success" onClick={handleAgregar}>
          ➕ Agregar Materia
        </button>
      </div>

      <div className="card shadow-sm">
        <div className="card-body">
          <div className="table-responsive">
            <table className="table table-hover align-middle">
              <thead>
                <tr>
                  <th>Código</th>
                  <th>Nombre</th>
                  <th>Descripción</th>
                  <th>Créditos</th>
                  <th>Estado</th>
                  <th className="text-center">Acciones</th>
                </tr>
              </thead>
              <tbody>
                {materias.length > 0 ? (
                  materias.map((mat) => (
                    <tr key={mat.codigo}>
                      <td><span className="badge bg-secondary">{mat.codigo}</span></td>
                      <td className="fw-bold">{mat.nombre}</td>
                      <td>{mat.descripcion}</td>
                      <td>{mat.creditos}</td>
                      <td>
                        <span className={`badge ${mat.estado === 'Activo' ? 'bg-success' : 'bg-danger'}`}>
                          {mat.estado}
                        </span>
                      </td>
                      <td className="text-center">
                        <button 
                          className="btn btn-sm btn-outline-success"
                          onClick={() => handleActualizar(mat)}
                        >
                          ✏️ Actualizar
                        </button>
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan="6" className="text-center text-muted py-4">No hay materias registradas.</td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      <MateriaModal 
        show={showModal} 
        onClose={() => setShowModal(false)} 
        onSave={handleSaveMateria} 
        materiaActual={materiaActual} 
      />
    </div>
  );
}