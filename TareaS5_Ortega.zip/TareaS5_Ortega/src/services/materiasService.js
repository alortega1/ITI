import axios from 'axios';

const API_URL = import.meta.env.VITE_API_URL || 'https://backend-academico-iti.onrender.com/api';

const apiClient = axios.create({
  baseURL: API_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

export const getMaterias = async () => {
  const response = await apiClient.get('/materias');
  return response.data;
};

export const getMateriaByCodigo = async (codigo) => {
  const response = await apiClient.get(`/materias/${codigo}`);
  return response.data;
};

export const createMateria = async (materia) => {
  const response = await apiClient.post('/materias', materia);
  return response.data;
};

export const updateMateria = async (codigo, materia) => {
  const response = await apiClient.put(`/materias/${codigo}`, materia);
  return response.data;
};

export const deleteMateria = async (codigo) => {
  const response = await apiClient.delete(`/materias/${codigo}`);
  return response.data;
};