import React, { useState } from 'react';
import Header from './components/Header';
import Nav from './components/Nav';
import Footer from './components/Footer';
import Estudiantes from './components/Estudiantes';
import Materias from './components/Materias';

export default function App() {
  const [vistaActual, setVistaActual] = useState('estudiantes');

  return (
    <div className="d-flex flex-column min-vh-100">
      <Header />
      <Nav vistaActual={vistaActual} setVistaActual={setVistaActual} />
      
      <main className="flex-fill">
        {vistaActual === 'estudiantes' ? <Estudiantes /> : <Materias />}
      </main>

      <Footer />
    </div>
  );
}