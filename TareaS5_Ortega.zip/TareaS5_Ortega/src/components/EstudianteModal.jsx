import React, { useState, useEffect } from 'react';

export default function EstudianteModal({ show, onClose, onSave, estudianteActual }) {
  const [formData, setFormData] = useState({
    cedula: '',
    nombres: '',
    apellidos: '',
    correo: '',
    carrera: ''
  });
  const [error, setError] = useState('');

  useEffect(() => {
    if (estudianteActual) {
      setFormData(estudianteActual);
    } else {
      setFormData({ cedula: '', nombres: '', apellidos: '', correo: '', carrera: '' });
    }
    setError('');
  }, [estudianteActual, show]);

  if (!show) return null;

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!formData.cedula || !formData.nombres || !formData.apellidos || !formData.correo || !formData.carrera) {
      setError('Todos los campos son obligatorios.');
      return;
    }
    onSave(formData);
    onClose();
  };

  return (
    <div className="modal show d-block" tabIndex="-1" style={{ backgroundColor: 'rgba(0,0,0,0.5)' }}>
      <div className="modal-dialog">
        <div className="modal-content">
          <div className="modal-header bg-primary text-white">
            <h5 className="modal-title">
              {estudianteActual ? 'Actualizar Estudiante' : 'Registrar Nuevo Estudiante'}
            </h5>
            <button type="button" className="btn-close btn-close-white" onClick={onClose}></button>
          </div>
          <form onSubmit={handleSubmit}>
            <div className="modal-body">
              {error && <div className="alert alert-danger py-2">{error}</div>}
              
              <div className="mb-3">
                <label className="form-label fw-bold">Número de Cédula</label>
                <input 
                  type="text" 
                  className="form-control" 
                  name="cedula" 
                  value={formData.cedula} 
                  onChange={handleChange} 
                  disabled={Boolean(estudianteActual)} 
                  placeholder="Ej. 1712345678"
                  required 
                />
                {estudianteActual && <small className="text-muted">La cédula no se puede modificar.</small>}
              </div>

              <div className="mb-3">
                <label className="form-label fw-bold">Nombres</label>
                <input 
                  type="text" 
                  className="form-control" 
                  name="nombres" 
                  value={formData.nombres} 
                  onChange={handleChange} 
                  placeholder="Ej. Juan Carlos"
                  required 
                />
              </div>

              <div className="mb-3">
                <label className="form-label fw-bold">Apellidos</label>
                <input 
                  type="text" 
                  className="form-control" 
                  name="apellidos" 
                  value={formData.apellidos} 
                  onChange={handleChange} 
                  placeholder="Ej. Pérez Gómez"
                  required 
                />
              </div>

              <div className="mb-3">
                <label className="form-label fw-bold">Correo Electrónico</label>
                <input 
                  type="email" 
                  className="form-control" 
                  name="correo" 
                  value={formData.correo} 
                  onChange={handleChange} 
                  placeholder="Ej. jperez@iti.edu.ec"
                  required 
                />
              </div>

              <div className="mb-3">
                <label className="form-label fw-bold">Carrera</label>
                <input 
                  type="text" 
                  className="form-control" 
                  name="carrera" 
                  value={formData.carrera} 
                  onChange={handleChange} 
                  placeholder="Ej. Desarrollo de Software"
                  required 
                />
              </div>
            </div>
            <div className="modal-footer">
              <button type="button" className="btn btn-secondary" onClick={onClose}>Cancelar</button>
              <button type="submit" className="btn btn-primary">Guardar cambios</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}