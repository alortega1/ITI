import React, { useState, useEffect } from 'react';
import {
  getMaterias,
  createMateria,
  updateMateria,
  deleteMateria,
} from '../services/materiasService';

export default function Materias() {
  const [materias, setMaterias] = useState([]);
  const [cargando, setCargando] = useState(true);
  const [mostrarFormulario, setMostrarFormulario] = useState(false);
  const [modoEdicion, setModoEdicion] = useState(false);

  // Estados para mensajes de retroalimentación al usuario
  const [mensaje, setMensaje] = useState({ tipo: '', texto: '' });
  const [erroresForm, setErroresForm] = useState({});

  // Estado del formulario
  const [formData, setFormData] = useState({
    codigo: '',
    nombre: '',
    descripcion: '',
    creditos: '',
    estado: 'Activo',
    carrera: '',
  });

  // Cargar materias al montar el componente
  useEffect(() => {
    cargarMaterias();
  }, []);

  const cargarMaterias = async () => {
    setCargando(true);
    try {
      const data = await getMaterias();
      // Soporta respuesta directa como array o envuelta en { data: [...] }
      setMaterias(Array.isArray(data) ? data : data.data || []);
    } catch (error) {
      mostrarAlerta('danger', 'Error al conectar con el servidor. No se pudieron cargar las materias.');
    } finally {
      setCargando(false);
    }
  };

  const mostrarAlerta = (tipo, texto) => {
    setMensaje({ tipo, texto });
    setTimeout(() => {
      setMensaje({ tipo: '', texto: '' });
    }, 5000);
  };

  // Validaciones requeridas (4.3)
  const validarFormulario = () => {
    const errores = {};
    const codigoLimpio = formData.codigo.trim();

    if (!codigoLimpio) {
      errores.codigo = 'El código es obligatorio.';
    } else if (!modoEdicion) {
      const existe = materias.some(
        (m) => m.codigo.toLowerCase() === codigoLimpio.toLowerCase()
      );
      if (existe) {
        errores.codigo = 'Este código ya se encuentra registrado.';
      }
    }

    if (!formData.nombre.trim()) {
      errores.nombre = 'El nombre de la materia es obligatorio.';
    }

    if (!formData.descripcion.trim()) {
      errores.descripcion = 'La descripción es obligatoria.';
    }

    const creditosNum = Number(formData.creditos);
    if (!formData.creditos || !Number.isInteger(creditosNum) || creditosNum <= 0) {
      errores.creditos = 'Los créditos deben ser un número entero mayor que cero.';
    }

    if (formData.estado !== 'Activo' && formData.estado !== 'Inactivo') {
      errores.estado = 'Seleccione un estado válido (Activo o Inactivo).';
    }

    if (!formData.carrera.trim()) {
      errores.carrera = 'La carrera es obligatoria.';
    }

    setErroresForm(errores);
    return Object.keys(errores).length === 0;
  };

  // Abrir formulario para nuevo registro
  const handleNuevo = () => {
    setModoEdicion(false);
    setErroresForm({});
    setFormData({
      codigo: '',
      nombre: '',
      descripcion: '',
      creditos: '',
      estado: 'Activo',
      carrera: '',
    });
    setMostrarFormulario(true);
  };

  // Abrir formulario para edición (4.4 - Oculta la tabla)
  const handleEditar = (materia) => {
    setModoEdicion(true);
    setErroresForm({});
    setFormData({
      codigo: materia.codigo,
      nombre: materia.nombre,
      descripcion: materia.descripcion || '',
      creditos: materia.creditos,
      estado: materia.estado || 'Activo',
      carrera: materia.carrera || '',
    });
    setMostrarFormulario(true);
  };

  // Cancelar y volver al listado
  const handleCancelar = () => {
    setMostrarFormulario(false);
    setErroresForm({});
  };

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  // Guardar (POST o PUT)
  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!validarFormulario()) return;

    // Payload limpio sin id ni fecha_registro
    const payload = {
      codigo: formData.codigo.trim(),
      nombre: formData.nombre.trim(),
      descripcion: formData.descripcion.trim(),
      creditos: parseInt(formData.creditos, 10),
      estado: formData.estado,
      carrera: formData.carrera.trim(),
    };

    try {
      if (modoEdicion) {
        await updateMateria(payload.codigo, payload);
        mostrarAlerta('success', `Materia "${payload.nombre}" actualizada correctamente.`);
      } else {
        await createMateria(payload);
        mostrarAlerta('success', `Materia "${payload.nombre}" registrada exitosamente.`);
      }
      setMostrarFormulario(false);
      cargarMaterias(); // Refresca la tabla desde la API
    } catch (error) {
      const msgServidor = error.response?.data?.message || error.response?.data?.error;
      mostrarAlerta(
        'danger',
        msgServidor || 'Ocurrió un error al guardar la materia en el servidor.'
      );
    }
  };

  // Eliminar con confirmación (4.5)
  const handleEliminar = async (materia) => {
    const confirmar = window.confirm(
      `¿Está seguro de que desea eliminar la materia "${materia.nombre}" (${materia.codigo})?`
    );
    if (!confirmar) return;

    try {
      await deleteMateria(materia.codigo);
      mostrarAlerta('success', `Materia "${materia.codigo}" eliminada correctamente.`);
      cargarMaterias();
    } catch (error) {
      mostrarAlerta('danger', 'No se pudo eliminar la materia. Verifique su conexión o permisos.');
    }
  };

  return (
    <div className="container my-4">
      {/* Encabezado del módulo */}
      <div className="d-flex justify-content-between align-items-center mb-4">
        <h2>
          <i className="bi bi-journal-bookmark-fill text-success me-2"></i>
          Gestión de Materias
        </h2>
        {!mostrarFormulario && (
          <button className="btn btn-success" onClick={handleNuevo}>
            <i className="bi bi-plus-circle me-2"></i>Nueva Materia
          </button>
        )}
      </div>

      {/* Alertas globales */}
      {mensaje.texto && (
        <div className={`alert alert-${mensaje.tipo} alert-dismissible fade show`} role="alert">
          <i className={`bi ${mensaje.tipo === 'success' ? 'bi-check-circle-fill' : 'bi-exclamation-triangle-fill'} me-2`}></i>
          {mensaje.texto}
          <button
            type="button"
            className="btn-close"
            onClick={() => setMensaje({ tipo: '', texto: '' })}
          ></button>
        </div>
      )}

      {/* VISTA FORMULARIO (Registro / Edición) */}
      {mostrarFormulario ? (
        <div className="card shadow-sm mx-auto" style={{ maxWidth: '700px' }}>
          <div className={`card-header text-white ${modoEdicion ? 'bg-warning text-dark' : 'bg-success'}`}>
            <h5 className="mb-0 fw-bold">
              <i className={`bi ${modoEdicion ? 'bi-pencil-square' : 'bi-plus-square'} me-2`}></i>
              {modoEdicion ? `Editar Materia (${formData.codigo})` : 'Registrar Nueva Materia'}
            </h5>
          </div>
          <div className="card-body p-4">
            <div className="alert alert-info py-2 small">
              <i className="bi bi-info-circle me-1"></i>
              <strong>Nota:</strong> Utiliza un código identificativo propio (ej. <code>MAT-AO01</code>) para no interferir con registros de otros compañeros.
            </div>

            <form onSubmit={handleSubmit} noValidate>
              <div className="row">
                <div className="col-md-6 mb-3">
                  <label className="form-label fw-bold">Código *</label>
                  <input
                    type="text"
                    name="codigo"
                    className={`form-control ${erroresForm.codigo ? 'is-invalid' : ''}`}
                    value={formData.codigo}
                    onChange={handleChange}
                    disabled={modoEdicion}
                    placeholder="Ej. MAT-AO01"
                  />
                  {erroresForm.codigo && <div className="invalid-feedback">{erroresForm.codigo}</div>}
                </div>

                <div className="col-md-6 mb-3">
                  <label className="form-label fw-bold">Créditos *</label>
                  <input
                    type="number"
                    name="creditos"
                    min="1"
                    step="1"
                    className={`form-control ${erroresForm.creditos ? 'is-invalid' : ''}`}
                    value={formData.creditos}
                    onChange={handleChange}
                    placeholder="Ej. 4"
                  />
                  {erroresForm.creditos && <div className="invalid-feedback">{erroresForm.creditos}</div>}
                </div>
              </div>

              <div className="mb-3">
                <label className="form-label fw-bold">Nombre de la Materia *</label>
                <input
                  type="text"
                  name="nombre"
                  className={`form-control ${erroresForm.nombre ? 'is-invalid' : ''}`}
                  value={formData.nombre}
                  onChange={handleChange}
                  placeholder="Ej. Arquitectura de Software"
                />
                {erroresForm.nombre && <div className="invalid-feedback">{erroresForm.nombre}</div>}
              </div>

              <div className="mb-3">
                <label className="form-label fw-bold">Descripción *</label>
                <textarea
                  name="descripcion"
                  rows="2"
                  className={`form-control ${erroresForm.descripcion ? 'is-invalid' : ''}`}
                  value={formData.descripcion}
                  onChange={handleChange}
                  placeholder="Diseño y arquitectura de sistemas..."
                ></textarea>
                {erroresForm.descripcion && <div className="invalid-feedback">{erroresForm.descripcion}</div>}
              </div>

              <div className="row">
                <div className="col-md-6 mb-3">
                  <label className="form-label fw-bold">Carrera *</label>
                  <input
                    type="text"
                    name="carrera"
                    className={`form-control ${erroresForm.carrera ? 'is-invalid' : ''}`}
                    value={formData.carrera}
                    onChange={handleChange}
                    placeholder="Ej. Desarrollo de Software"
                  />
                  {erroresForm.carrera && <div className="invalid-feedback">{erroresForm.carrera}</div>}
                </div>

                <div className="col-md-6 mb-3">
                  <label className="form-label fw-bold">Estado *</label>
                  <select
                    name="estado"
                    className={`form-select ${erroresForm.estado ? 'is-invalid' : ''}`}
                    value={formData.estado}
                    onChange={handleChange}
                  >
                    <option value="Activo">Activo</option>
                    <option value="Inactivo">Inactivo</option>
                  </select>
                  {erroresForm.estado && <div className="invalid-feedback">{erroresForm.estado}</div>}
                </div>
              </div>

              <div className="d-flex justify-content-end gap-2 mt-3">
                <button type="button" className="btn btn-secondary" onClick={handleCancelar}>
                  <i className="bi bi-x-circle me-1"></i>Cancelar
                </button>
                <button type="submit" className="btn btn-success">
                  <i className="bi bi-save me-1"></i>Guardar
                </button>
              </div>
            </form>
          </div>
        </div>
      ) : (
        /* VISTA TABLA DE LISTADO (4.2) */
        <div className="card shadow-sm">
          <div className="card-body">
            {cargando ? (
              <div className="text-center py-5">
                <div className="spinner-border text-success" role="status"></div>
                <p className="mt-2 text-muted">Cargando materias desde el servidor...</p>
              </div>
            ) : (
              <div className="table-responsive">
                <table className="table table-hover align-middle">
                  <thead>
                    <tr>
                      <th>Código</th>
                      <th>Nombre</th>
                      <th>Descripción</th>
                      <th className="text-center">Créditos</th>
                      <th>Carrera</th>
                      <th className="text-center">Estado</th>
                      <th className="text-center">Acciones</th>
                    </tr>
                  </thead>
                  <tbody>
                    {materias.length > 0 ? (
                      materias.map((mat) => (
                        <tr key={mat.codigo}>
                          <td><span className="badge bg-dark">{mat.codigo}</span></td>
                          <td className="fw-bold">{mat.nombre}</td>
                          <td>{mat.descripcion}</td>
                          <td className="text-center">{mat.creditos}</td>
                          <td>{mat.carrera}</td>
                          <td className="text-center">
                            <span className={`badge ${mat.estado === 'Activo' ? 'bg-success' : 'bg-danger'}`}>
                              {mat.estado}
                            </span>
                          </td>
                          <td className="text-center text-nowrap">
                            <button
                              className="btn btn-sm btn-outline-warning me-2"
                              title="Editar"
                              onClick={() => handleEditar(mat)}
                            >
                              <i className="bi bi-pencil-fill"></i> Editar
                            </button>
                            <button
                              className="btn btn-sm btn-outline-danger"
                              title="Eliminar"
                              onClick={() => handleEliminar(mat)}
                            >
                              <i className="bi bi-trash-fill"></i> Eliminar
                            </button>
                          </td>
                        </tr>
                      ))
                    ) : (
                      <tr>
                        <td colSpan="7" className="text-center text-muted py-4">
                          No existen materias registradas en la base de datos.
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}