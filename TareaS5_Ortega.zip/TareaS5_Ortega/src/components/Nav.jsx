import React from 'react';

export default function Nav({ vistaActual, setVistaActual, usuario, onLogout }) {
  return (
    <nav className="navbar navbar-expand-lg navbar-dark bg-dark mb-4 shadow-sm">
      <div className="container">
        <span className="navbar-brand">
          <i className="bi bi-grid-fill me-2"></i>Menú Principal
        </span>
        <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
          <span className="navbar-toggler-icon"></span>
        </button>
        <div className="collapse navbar-collapse" id="navbarNav">
          <ul className="navbar-nav me-auto">
            <li className="nav-item">
              <button 
                className={`nav-link btn btn-link ${vistaActual === 'estudiantes' ? 'active fw-bold text-warning' : 'text-white'}`}
                onClick={() => setVistaActual('estudiantes')}
              >
                <i className="bi bi-people-fill me-1"></i> Estudiantes
              </button>
            </li>
            <li className="nav-item">
              <button 
                className={`nav-link btn btn-link ${vistaActual === 'materias' ? 'active fw-bold text-warning' : 'text-white'}`}
                onClick={() => setVistaActual('materias')}
              >
                <i className="bi bi-book-fill me-1"></i> Materias
              </button>
            </li>
          </ul>
          <div className="d-flex align-items-center text-white gap-3">
            <span className="small"><i className="bi bi-person-circle me-1"></i>{usuario}</span>
            <button className="btn btn-sm btn-outline-light" onClick={onLogout}>
              <i className="bi bi-box-arrow-right me-1"></i>Salir
            </button>
          </div>
        </div>
      </div>
    </nav>
  );
}