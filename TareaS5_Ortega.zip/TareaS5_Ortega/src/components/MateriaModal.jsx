import React, { useState, useEffect } from 'react';

export default function MateriaModal({ show, onClose, onSave, materiaActual }) {
  const [formData, setFormData] = useState({
    codigo: '',
    nombre: '',
    descripcion: '',
    creditos: '',
    estado: 'Activo'
  });
  const [error, setError] = useState('');

  useEffect(() => {
    if (materiaActual) {
      setFormData(materiaActual);
    } else {
      setFormData({ codigo: '', nombre: '', descripcion: '', creditos: '', estado: 'Activo' });
    }
    setError('');
  }, [materiaActual, show]);

  if (!show) return null;

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!formData.codigo || !formData.nombre || !formData.descripcion || !formData.creditos) {
      setError('Todos los campos obligatorios deben estar llenos.');
      return;
    }
    if (Number(formData.creditos) <= 0) {
      setError('El número de créditos debe ser mayor que cero.');
      return;
    }
    onSave(formData);
    onClose();
  };

  return (
    <div className="modal show d-block" tabIndex="-1" style={{ backgroundColor: 'rgba(0,0,0,0.5)' }}>
      <div className="modal-dialog">
        <div className="modal-content">
          <div className="modal-header bg-success text-white">
            <h5 className="modal-title">
              {materiaActual ? 'Actualizar Materia' : 'Registrar Nueva Materia'}
            </h5>
            <button type="button" className="btn-close btn-close-white" onClick={onClose}></button>
          </div>
          <form onSubmit={handleSubmit}>
            <div className="modal-body">
              {error && <div className="alert alert-danger py-2">{error}</div>}

              <div className="mb-3">
                <label className="form-label fw-bold">Código Alfanumérico</label>
                <input 
                  type="text" 
                  className="form-control" 
                  name="codigo" 
                  value={formData.codigo} 
                  onChange={handleChange} 
                  disabled={Boolean(materiaActual)} 
                  placeholder="Ej. MAT-101"
                  required 
                />
                {materiaActual && <small className="text-muted">El código no se puede modificar.</small>}
              </div>

              <div className="mb-3">
                <label className="form-label fw-bold">Nombre</label>
                <input 
                  type="text" 
                  className="form-control" 
                  name="nombre" 
                  value={formData.nombre} 
                  onChange={handleChange} 
                  placeholder="Ej. Programación Web"
                  required 
                />
              </div>

              <div className="mb-3">
                <label className="form-label fw-bold">Descripción</label>
                <textarea 
                  className="form-control" 
                  name="descripcion" 
                  value={formData.descripcion} 
                  onChange={handleChange} 
                  rows="2"
                  placeholder="Breve descripción de la asignatura..."
                  required 
                ></textarea>
              </div>

              <div className="mb-3">
                <label className="form-label fw-bold">Número de Créditos</label>
                <input 
                  type="number" 
                  className="form-control" 
                  name="creditos" 
                  min="1"
                  value={formData.creditos} 
                  onChange={handleChange} 
                  placeholder="Ej. 4"
                  required 
                />
              </div>

              <div className="mb-3">
                <label className="form-label fw-bold">Estado</label>
                <select 
                  className="form-select" 
                  name="estado" 
                  value={formData.estado} 
                  onChange={handleChange}
                >
                  <option value="Activo">Activo</option>
                  <option value="Inactivo">Inactivo</option>
                </select>
              </div>
            </div>
            <div className="modal-footer">
              <button type="button" className="btn btn-secondary" onClick={onClose}>Cancelar</button>
              <button type="submit" className="btn btn-success">Guardar cambios</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}