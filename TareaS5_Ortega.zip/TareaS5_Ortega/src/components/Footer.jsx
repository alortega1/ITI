import React from 'react';

export default function Footer() {
  return (
    <footer className="text-center py-4 mt-auto border-top">
      <div className="container">
        <p className="m-0 small">Sistema Académico ITI &copy; 2026 - Desarrollo de Aplicaciones Web y Móviles</p>
      </div>
    </footer>
  );
}