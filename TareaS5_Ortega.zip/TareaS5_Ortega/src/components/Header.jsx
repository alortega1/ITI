import React from 'react';

export default function Header() {
  return (
    <header className="bg-primary text-white py-3 shadow-sm">
      <div className="container d-flex justify-content-between align-items-center">
        <h1 className="h4 m-0 fw-bold">🎓 Sistema Académico ITI</h1>
        <span className="badge bg-light text-primary fs-6">Evaluación Práctica - React.js</span>
      </div>
    </header>
  );
}