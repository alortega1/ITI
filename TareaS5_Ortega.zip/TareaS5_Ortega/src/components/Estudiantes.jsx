import React, { useState } from 'react';
import EstudianteModal from './EstudianteModal';

export default function Estudiantes() {
  const [estudiantes, setEstudiantes] = useState([
    { cedula: '1711223344', nombres: 'Carlos Andrés', apellidos: 'Mendoza Ruiz', correo: 'cmendoza@iti.edu.ec', carrera: 'Desarrollo de Software' },
    { cedula: '1722334455', nombres: 'Ana María', apellidos: 'López Torres', correo: 'alopez@iti.edu.ec', carrera: 'Redes y Telecomunicaciones' }
  ]);

  const [showModal, setShowModal] = useState(false);
  const [estudianteActual, setEstudianteActual] = useState(null);

  const handleAgregar = () => {
    setEstudianteActual(null);
    setShowModal(true);
  };

  const handleActualizar = (estudiante) => {
    setEstudianteActual(estudiante);
    setShowModal(true);
  };

  const handleSaveEstudiante = (estudianteData) => {
    if (estudianteActual) {
      setEstudiantes(estudiantes.map(e => e.cedula === estudianteData.cedula ? estudianteData : e));
    } else {
      const existe = estudiantes.some(e => e.cedula === estudianteData.cedula);
      if (existe) {
        alert('Ya existe un estudiante registrado con esta cédula.');
        return;
      }
      setEstudiantes([...estudiantes, estudianteData]);
    }
  };

  return (
    <div className="container my-4">
      <div className="d-flex justify-content-between align-items-center mb-4">
        <h2>👥 Gestión de Estudiantes</h2>
        <button className="btn btn-primary" onClick={handleAgregar}>
          ➕ Agregar Estudiante
        </button>
      </div>

      <div className="card shadow-sm">
        <div className="card-body">
          <div className="table-responsive">
            <table className="table table-hover align-middle">
              <thead>
                <tr>
                  <th>Cédula</th>
                  <th>Nombres</th>
                  <th>Apellidos</th>
                  <th>Correo</th>
                  <th>Carrera</th>
                  <th className="text-center">Acciones</th>
                </tr>
              </thead>
              <tbody>
                {estudiantes.length > 0 ? (
                  estudiantes.map((est) => (
                    <tr key={est.cedula}>
                      <td>{est.cedula}</td>
                      <td>{est.nombres}</td>
                      <td>{est.apellidos}</td>
                      <td>{est.correo}</td>
                      <td>{est.carrera}</td>
                      <td className="text-center">
                        <button 
                          className="btn btn-sm btn-outline-primary"
                          onClick={() => handleActualizar(est)}
                        >
                          ✏️ Actualizar
                        </button>
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan="6" className="text-center text-muted py-4">No hay estudiantes registrados.</td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      <EstudianteModal 
        show={showModal} 
        onClose={() => setShowModal(false)} 
        onSave={handleSaveEstudiante} 
        estudianteActual={estudianteActual} 
      />
    </div>
  );
}