// Variable global para almacenar el valor del contador
let contador = 0;

function incrementar() {
    contador++; // Incrementar variable global
    actualizarDisplay();
}

function reiniciar() {
    contador = 0; // Reiniciar a 0
    actualizarDisplay();
}

// Función auxiliar para actualizar el DOM
function actualizarDisplay() {
    const display = document.getElementById('displayContador');
    display.textContent = contador;
}