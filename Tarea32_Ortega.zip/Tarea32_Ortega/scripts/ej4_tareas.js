// Array para almacenar la lista de tareas
const tareas = [];

function agregarTarea() {
    const input = document.getElementById('tareaInput');
    const textoTarea = input.value.trim();
    const alerta = document.getElementById('alertaValidacion');
    const ulLista = document.getElementById('listaTareas');

    // Validar que no esté vacía
    if (textoTarea === '') {
        alerta.classList.remove('d-none');
        return;
    }

    // Ocultar alerta si estaba visible
    alerta.classList.add('d-none');

    // Agregar elemento al Array
    tareas.push(textoTarea);

    // Crear nodo <li> mediante el DOM
    const li = document.createElement('li');
    li.className = 'list-group-item d-flex justify-content-between align-items-center';
    li.textContent = textoTarea;

    // Crear botón para eliminar tarea
    const btnEliminar = document.createElement('button');
    btnEliminar.className = 'btn btn-sm btn-outline-danger';
    btnEliminar.textContent = '✕';
    btnEliminar.onclick = function() {
        li.remove();
    };

    // Agregar botón dentro de <li> y luego <li> a <ul> con appendChild
    li.appendChild(btnEliminar);
    ulLista.appendChild(li);

    // Limpiar campo de texto y dar foco de nuevo
    input.value = '';
    input.focus();
}