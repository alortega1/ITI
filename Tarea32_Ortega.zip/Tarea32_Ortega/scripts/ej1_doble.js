function calcularDoble() {
    const input = document.getElementById('numeroInput').value;
    const cajaResultado = document.getElementById('resultadoDoble');
    
    // Validación de entrada vacía
    if (input === '') {
        cajaResultado.className = 'alert alert-warning text-center fw-bold m-0';
        cajaResultado.textContent = 'Por favor, ingrese un número válido.';
        return;
    }
    
    const numero = parseFloat(input);
    const doble = numero * 2;
    
    // Mostrar resultado
    cajaResultado.className = 'alert alert-success text-center fw-bold m-0';
    cajaResultado.textContent = `Ingreso: ${numero} → El doble es: ${doble}`;
}