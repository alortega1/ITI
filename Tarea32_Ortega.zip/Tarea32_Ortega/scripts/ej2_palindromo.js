function verificarPalindromo() {
    const textoOriginal = document.getElementById('palindromoInput').value.trim();
    const cajaResultado = document.getElementById('resultadoPalindromo');

    // Validar input vacío
    if (textoOriginal === '') {
        cajaResultado.className = 'alert alert-warning text-center fw-bold m-0';
        cajaResultado.textContent = 'Ingrese un número o texto primero.';
        return;
    }

    // Invertir cadena usando split(), reverse() y join()
    const textoInvertido = textoOriginal.split('').reverse().join('');

    // Estructura de decisión (if)
    if (textoOriginal === textoInvertido) {
        cajaResultado.className = 'alert alert-success text-center fw-bold m-0';
        cajaResultado.textContent = `${textoOriginal} (Es palíndromo)`;
    } else {
        cajaResultado.className = 'alert alert-danger text-center fw-bold m-0';
        cajaResultado.textContent = `${textoOriginal} (No es palíndromo)`;
    }
}